using IntervalRootFinding
using Test

include("roots.jl")
include("test_smiley.jl")
include("newton1d.jl")
include("quadratic.jl")
include("linear_eq.jl")
include("slopes.jl")
