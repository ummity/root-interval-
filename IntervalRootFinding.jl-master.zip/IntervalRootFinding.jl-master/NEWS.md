# Updates to `IntervalRootFinding.jl`

## v0.2

The package has been completely rewritten for v0.2.
It now contains basic bisection and Newton interval routines for functions with an arbitrary number of parameters.
