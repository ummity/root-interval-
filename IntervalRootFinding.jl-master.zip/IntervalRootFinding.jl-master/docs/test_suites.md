
# Test suites:

- http://folk.uib.no/ssu029/Pdf_file/Testproblems/testprobRheinboldt03.pdf

-  http://www.mat.univie.ac.at/~neum/glopt/test.html

-  http://titan.princeton.edu/TestProblems/

- http://www-sop.inria.fr/saga/POL/

-  MINPACK benchmarks: https://github.com/JuliaNLSolvers/NLsolve.jl/blob/master/test/minpack.jl

 and other files in NLsolve test suite


# Papers

- Testing unconstrained optimization software, Moré, Garbow, Hillstrom ACM Trans. Math. Soft. 7 (1), 17-41 (1981)
