# Bibliography

  - *Applied Interval Analysis*, L. Jaulin, M. Kieffer, O. Didrit & E. Walter. Springer (2001)
  - *Global Optimization Using Interval Analysis: Revised And Expanded*, E. Hansen & G.W. Walster. CRC Press (2003)
  - *Introduction to Interval Analysis*, R.E. Moore, R.B. Kearfott & M.J. Cloud. SIAM (2009)
  - *Validated Numerics: A Short Introduction to Rigorous Computations*, W. Tucker. Princeton University Press (2010)
